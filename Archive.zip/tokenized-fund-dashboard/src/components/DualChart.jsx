import React, { useState } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';
import { useQuery, gql } from '@apollo/client';

const NAV_HISTORY = gql`
  query GetNavHistory($fundId: ID!) {
    navHistory(fundId: $fundId) {
      nav
      timestamp
    }
  }
`;

const YIELD_HISTORY = gql`
  query GetYieldHistory($fundId: ID!) {
    fund(id: $fundId) {
      yieldHistory {
        timestamp
        yield
      }
    }
  }
`;

export default function DualChart({ fundId }) {
  const [activeTab, setActiveTab] = useState('yield');

  const { data: navData } = useQuery(NAV_HISTORY, {
    variables: { fundId },
    pollInterval: 15000,
  });

  const { data: yieldData } = useQuery(YIELD_HISTORY, {
    variables: { fundId },
    pollInterval: 15000,
  });

  const formattedYield =
    yieldData?.fund?.yieldHistory?.map((item) => ({
      time: new Date(item.timestamp).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      }),
      yield: item.yield,
    })) || [];

  const formattedNAV =
    navData?.navHistory?.map((item) => ({
      time: new Date(item.timestamp).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      }),
      nav: item.nav,
    })) || [];

  const data = activeTab === 'yield' ? formattedYield : formattedNAV;

  // If data is loading or empty, show loading indicator
  if (!formattedYield.length && !formattedNAV.length) {
    return (
      <div className="w-full h-64 flex items-center justify-center bg-gray-50">
        <p className="text-gray-400">Loading chart data...</p>
      </div>
    );
  }

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded shadow-sm">
          <p className="font-medium">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name === 'yield' ? 'Yield: ' : 'NAV: '}
              <span className="font-medium">
                {entry.name === 'yield'
                  ? `${entry.value.toFixed(4)}%`
                  : `$${entry.value.toFixed(2)}`}
              </span>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full h-full">
      <div className="flex mb-3 border-b border-gray-200">
        <button
          className={`px-4 py-2 text-sm font-medium ${
            activeTab === 'yield'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
          onClick={() => setActiveTab('yield')}
        >
          Intraday Yield
        </button>
        {formattedNAV.length > 0 && (
          <button
            className={`px-4 py-2 text-sm font-medium ${
              activeTab === 'nav'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('nav')}
          >
            NAV History
          </button>
        )}
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={data} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="colorYield" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8} />
              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="colorNav" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#10b981" stopOpacity={0.8} />
              <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis
            dataKey="time"
            tick={{ fontSize: 12 }}
            tickLine={false}
            axisLine={false}
            minTickGap={30}
          />
          <YAxis
            orientation="right"
            tick={{ fontSize: 12 }}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) =>
              activeTab === 'yield'
                ? `${value.toFixed(2)}%`
                : `$${value.toFixed(2)}`
            }
          />
          <Tooltip content={<CustomTooltip />} />
          {activeTab === 'yield' && (
            <Area
              type="monotone"
              dataKey="yield"
              stroke="#3b82f6"
              fill="url(#colorYield)"
              fillOpacity={1}
              name="yield"
            />
          )}
          {activeTab === 'nav' && (
            <Area
              type="monotone"
              dataKey="nav"
              stroke="#10b981"
              fill="url(#colorNav)"
              fillOpacity={1}
              name="nav"
            />
          )}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
