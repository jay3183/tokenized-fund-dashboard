// src/App.jsx
import { useState, useEffect, createContext, useContext } from 'react';
import {
  gql,
  useQuery,
  useMutation,
} from '@apollo/client';
import toast, { Toaster } from 'react-hot-toast';
import { Card, CardContent, Button } from '@/components/ui';
import DualChart from '@/components/DualChart';

const RoleContext = createContext();
export const useRole = () => useContext(RoleContext);

const FUNDS_QUERY = gql`
  query GetAllFunds {
    allFunds {
      id
      name
      currentNAV {
        nav
        timestamp
      }
    }
  }
`;

const MINT_SHARES = gql`
  mutation Mint($fundId: ID!, $investorId: ID!, $amountUSD: Float!) {
    mintShares(fundId: $fundId, investorId: $investorId, amountUSD: $amountUSD) {
      sharesMinted
      navUsed
      timestamp
    }
  }
`;

const REDEEM_SHARES = gql`
  mutation Redeem($fundId: ID!, $investorId: ID!, $shares: Float!) {
    redeemShares(fundId: $fundId, investorId: $investorId, shares: $shares) {
      sharesRedeemed
      navUsed
      amountUSD
      timestamp
    }
  }
`;

const PORTFOLIO_QUERY = gql`
  query GetPortfolio($investorId: ID!, $fundId: ID!) {
    portfolio(investorId: $investorId, fundId: $fundId) {
      shares
    }
  }
`;

const AUDIT_LOGS = gql`
  query AuditLogs($fundId: ID!) {
    auditLogs(fundId: $fundId) {
      timestamp
      actor
      action
      metadata
    }
  }
`;

function PortfolioPanel({ investorId, fundId }) {
  const { loading, error, data } = useQuery(PORTFOLIO_QUERY, {
    variables: { investorId, fundId },
    pollInterval: 10000,
  });

  if (loading) return <p className="text-sm text-gray-400">Loading portfolio...</p>;
  if (error || !data.portfolio) return <p className="text-sm text-red-500">No portfolio data</p>;

  return (
    <p className="text-sm text-green-600">
      ✅ You currently hold <strong>{data.portfolio.shares.toFixed(2)}</strong> shares.
    </p>
  );
}

function AuditLog({ fundId }) {
  const { loading, error, data } = useQuery(AUDIT_LOGS, {
    variables: { fundId },
    pollInterval: 10000,
  });

  if (loading) return <p className="text-sm text-gray-400">Loading logs...</p>;
  if (error) return <p className="text-sm text-red-500">Error loading logs</p>;

  return (
    <div className="mt-4 text-sm">
      <h3 className="font-semibold">Audit Log:</h3>
      <ul className="mt-2 space-y-1">
        {data.auditLogs.map((log, i) => (
          <li key={i} className="text-gray-600">
            [{new Date(log.timestamp).toLocaleTimeString()}] <strong>{log.actor}</strong> →{' '}
            {log.action} ({JSON.stringify(log.metadata)})
          </li>
        ))}
      </ul>
    </div>
  );
}

function FundList() {
  const { role } = useRole();
  const { loading, error, data, refetch } = useQuery(FUNDS_QUERY);
  const [mintShares] = useMutation(MINT_SHARES);
  const [redeemShares] = useMutation(REDEEM_SHARES);

  useEffect(() => {
    const interval = setInterval(() => refetch(), 10000);
    return () => clearInterval(interval);
  }, [refetch]);

  if (loading) return <p className="text-sm text-gray-500 p-4">Loading funds...</p>;
  if (error)
    return (
      <div className="bg-red-50 text-red-700 p-4 border border-red-300 rounded m-4">
        <strong>GraphQL Error:</strong> {error.message}
      </div>
    );

  return (
    <div className="grid gap-4 p-4">
      {data.allFunds.map((fund) => (
        <Card key={fund.id}>
          <CardContent className="space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">{fund.name}</h2>
              <p className="text-sm text-gray-400">
                NAV: ${fund.currentNAV.nav.toFixed(2)} • Updated:{' '}
                {new Date(fund.currentNAV.timestamp).toLocaleTimeString()}
              </p>
            </div>

            <DualChart fundId={fund.id} />

            {role === 'INVESTOR' && (
              <>
                <PortfolioPanel investorId="1" fundId={fund.id} />
                <div className="flex gap-2 pt-2">
                  <Button
                    onClick={() =>
                      mintShares({
                        variables: { fundId: fund.id, investorId: '1', amountUSD: 500 },
                      })
                        .then(() => toast.success('✅ Minted $500 shares!'))
                        .catch(() => toast.error('Minting failed'))
                    }
                  >
                    + Mint Shares
                  </Button>
                  <Button
                    onClick={() =>
                      redeemShares({
                        variables: { fundId: fund.id, investorId: '1', shares: 10 },
                      })
                        .then(() => toast.success('✅ Redeemed 10 shares!'))
                        .catch(() => toast.error('Redeem failed'))
                    }
                    variant="secondary"
                  >
                    – Redeem Shares
                  </Button>
                </div>
              </>
            )}

            {role === 'ADMIN' && <AuditLog fundId={fund.id} />}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export default function App() {
  const [role, setRole] = useState('INVESTOR');

  return (
    <RoleContext.Provider value={{ role }}>
      <Toaster position="bottom-right" />
      <div className="min-h-screen bg-gray-50">
        <header className="flex justify-between items-center p-4 bg-white shadow">
          <h1 className="text-2xl font-bold text-blue-800">Tokenized Fund Dashboard</h1>
          <select
            className="border rounded p-1"
            value={role}
            onChange={(e) => setRole(e.target.value)}
          >
            <option value="INVESTOR">Investor</option>
            <option value="ADMIN">Admin</option>
          </select>
        </header>
        <FundList />
      </div>
    </RoleContext.Provider>
  );
}
